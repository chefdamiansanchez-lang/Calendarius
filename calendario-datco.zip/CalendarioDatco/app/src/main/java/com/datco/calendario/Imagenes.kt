package com.datco.calendario

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

// Fotos reales de paisajes argentinos (Wikimedia Commons), una por mes según la estación.
// Se descargan una sola vez y quedan guardadas en el teléfono.
object Imagenes {
    private val consultas = arrayOf(
        "Mar del Plata playa",                // Enero (verano)
        "Cataratas del Iguazú",               // Febrero (verano)
        "Mendoza viñedos",                    // Marzo (otoño)
        "Lago Nahuel Huapi otoño",            // Abril (otoño)
        "Quebrada de Humahuaca",              // Mayo (otoño)
        "Cerro Catedral Bariloche nieve",     // Junio (invierno)
        "Perito Moreno glaciar",              // Julio (invierno)
        "Ushuaia invierno nieve",             // Agosto (invierno)
        "Jacarandá Buenos Aires",             // Septiembre (primavera)
        "Jardín Japonés Buenos Aires",        // Octubre (primavera)
        "Lago Puelo",                         // Noviembre (primavera)
        "Salinas Grandes Jujuy"               // Diciembre (verano)
    )

    private val ui = Handler(Looper.getMainLooper())

    private fun archivo(c: Context, mes: Int) = File(c.filesDir, "mes_$mes.jpg")

    fun cargar(c: Context, mes: Int, vista: ImageView) {
        vista.tag = mes
        val f = archivo(c, mes)
        if (f.exists()) {
            mostrar(f, vista, mes)
            return
        }
        vista.setImageDrawable(null)
        thread {
            try {
                val url = buscar(consultas[mes - 1]) ?: return@thread
                abrir(url).inputStream.use { ent -> f.outputStream().use { sal -> ent.copyTo(sal) } }
                ui.post { mostrar(f, vista, mes) }
            } catch (e: Exception) {
                f.delete()
            }
        }
    }

    private fun mostrar(f: File, vista: ImageView, mes: Int) {
        if (vista.tag != mes) return
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp != null) vista.setImageBitmap(bmp) else f.delete()
    }

    private fun abrir(u: String): HttpURLConnection {
        val con = URL(u).openConnection() as HttpURLConnection
        con.setRequestProperty("User-Agent", "DatcoCalendario/2.0 (app de calendario)")
        con.connectTimeout = 15000
        con.readTimeout = 20000
        con.instanceFollowRedirects = true
        return con
    }

    private fun buscar(consulta: String): String? {
        val q = URLEncoder.encode("$consulta filetype:bitmap", "UTF-8")
        val api = "https://commons.wikimedia.org/w/api.php?action=query&format=json" +
            "&generator=search&gsrnamespace=6&gsrlimit=12&gsrsearch=$q" +
            "&prop=imageinfo&iiprop=url%7Cmime%7Csize&iiurlwidth=1000"
        val txt = abrir(api).inputStream.bufferedReader().use { it.readText() }
        val pages = JSONObject(txt).optJSONObject("query")?.optJSONObject("pages") ?: return null
        var mejor: String? = null
        var idx = Int.MAX_VALUE
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val info = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            if (info.optString("mime") != "image/jpeg") continue
            val w = info.optInt("width")
            val h = info.optInt("height")
            if (w < 1200 || w <= h) continue
            val i = p.optInt("index", 999)
            if (i < idx) {
                idx = i
                mejor = info.optString("thumburl", info.optString("url"))
            }
        }
        return mejor
    }
}
