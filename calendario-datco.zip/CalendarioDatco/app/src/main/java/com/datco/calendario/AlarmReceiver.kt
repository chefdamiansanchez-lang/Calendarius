package com.datco.calendario

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val titulo = i.getStringExtra("titulo") ?: "Recordatorio"
        val id = i.getLongExtra("id", 0L)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val canal = "alarma_calendario"
        if (nm.getNotificationChannel(canal) == null) {
            val ch = NotificationChannel(canal, "Alarmas del calendario", NotificationManager.IMPORTANCE_HIGH)
            val attr = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attr)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
            nm.createNotificationChannel(ch)
        }
        val abrir = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, canal)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("⏰ Recordatorio")
            .setContentText(titulo)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(abrir)
            .setAutoCancel(true)
            .build()
        nm.notify((id % 1000000007L).toInt(), n)
    }
}
