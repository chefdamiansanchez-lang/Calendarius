package com.datco.calendario

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Alarmas {
    fun momento(t: Tarea): Long {
        val p = t.fecha.split("-")
        val cal = Calendar.getInstance()
        cal.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt(), t.hora, t.minuto, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun pi(c: Context, id: Long, titulo: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("id", id)
            .putExtra("titulo", titulo)
        return PendingIntent.getBroadcast(
            c, (id % 1000000007L).toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun programar(c: Context, t: Tarea) {
        if (!t.alarma || t.hecha) return
        val m = momento(t)
        if (m <= System.currentTimeMillis()) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val abrir = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock suena a la hora exacta y no necesita permisos especiales
        am.setAlarmClock(AlarmManager.AlarmClockInfo(m, abrir), pi(c, t.id, t.titulo))
    }

    fun cancelar(c: Context, id: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, id, ""))
    }

    fun reprogramarTodas(c: Context) {
        for (t in Store.todas(c)) programar(c, t)
    }
}
