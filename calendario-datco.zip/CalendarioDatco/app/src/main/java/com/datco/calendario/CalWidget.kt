package com.datco.calendario

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

class CalWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, vista(c))
    }

    companion object {
        fun vista(c: Context): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            val hoy = Calendar.getInstance()
            val hoyTxt = fechaTexto(
                hoy.get(Calendar.YEAR), hoy.get(Calendar.MONTH), hoy.get(Calendar.DAY_OF_MONTH)
            )
            rv.setTextViewText(R.id.w_dia, hoy.get(Calendar.DAY_OF_MONTH).toString())
            rv.setTextViewText(R.id.w_semana, DIAS[hoy.get(Calendar.DAY_OF_WEEK) - 1])
            rv.setTextViewText(R.id.w_mes, "${MESES[hoy.get(Calendar.MONTH)]} ${hoy.get(Calendar.YEAR)}")

            val prox = Store.todas(c)
                .filter { !it.hecha && it.fecha >= hoyTxt }
                .sortedWith(compareBy({ it.fecha }, { it.hora }, { it.minuto }))
                .take(3)
            val txt = if (prox.isEmpty()) "Sin tareas pendientes" else prox.joinToString("\n") { t ->
                val p = t.fecha.split("-")
                "${p[2]}/${p[1]}  ${"%02d:%02d".format(t.hora, t.minuto)}  ${t.titulo}"
            }
            rv.setTextViewText(R.id.w_tareas, txt)

            val abrir = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.w_root, abrir)
            return rv
        }

        fun refrescar(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, CalWidget::class.java))
            for (id in ids) m.updateAppWidget(id, vista(c))
        }
    }
}
