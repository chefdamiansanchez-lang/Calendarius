package com.datco.calendario

import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class DiaActivity : AppCompatActivity() {
    private var fecha: String = ""
    private var color: Int = 0
    private lateinit var lista: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fecha = intent.getStringExtra("fecha") ?: ""
        if (fecha.isEmpty()) {
            finish()
            return
        }
        val p = fecha.split("-")
        val y = p[0].toInt()
        val m = p[1].toInt()
        val d = p[2].toInt()
        val c = Calendar.getInstance().apply { set(y, m - 1, d) }
        color = Estacion.color(m)
        val titulo = "${DIAS[c.get(Calendar.DAY_OF_WEEK) - 1]} $d de ${MESES[m - 1].lowercase()}"

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val cab = TextView(this).apply {
            text = "‹   $titulo"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setBackgroundColor(color)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setOnClickListener { finish() }
        }
        raiz.addView(cab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        scroll.addView(lista)
        raiz.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val btn = Button(this).apply {
            text = "+ Agregar tarea o recordatorio"
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            setOnClickListener { agregar() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), dp(8), dp(16), dp(16))
        raiz.addView(btn, lp)

        setContentView(raiz)
        render()
    }

    private fun render() {
        lista.removeAllViews()
        val ts = Store.deDia(this, fecha)
        if (ts.isEmpty()) {
            lista.addView(TextView(this).apply {
                text = "Sin tareas para este día"
                textSize = 16f
                setTextColor(0xFF616161.toInt())
                setPadding(dp(20), dp(30), dp(20), 0)
            })
            return
        }
        for (t in ts) {
            val fila = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            val ck = CheckBox(this).apply {
                isChecked = t.hecha
                setOnCheckedChangeListener { _, v ->
                    Store.marcar(this@DiaActivity, t.id, v)
                    render()
                }
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val tit = TextView(this).apply {
                text = t.titulo
                textSize = 18f
                setTextColor(0xFF212121.toInt())
                if (t.hecha) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            }
            val hora = TextView(this).apply {
                text = "%02d:%02d".format(t.hora, t.minuto) + (if (t.alarma) "   ⏰ alarma" else "")
                textSize = 14f
                setTextColor(color)
            }
            col.addView(tit)
            col.addView(hora)
            val x = TextView(this).apply {
                text = "✕"
                textSize = 22f
                setTextColor(0xFFD32F2F.toInt())
                setPadding(dp(14), dp(6), dp(6), dp(6))
                setOnClickListener {
                    Store.borrar(this@DiaActivity, t.id)
                    render()
                }
            }
            fila.addView(ck)
            fila.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            fila.addView(x)
            lista.addView(fila)
            lista.addView(View(this).apply { setBackgroundColor(0xFFEEEEEE.toInt()) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        }
    }

    private fun agregar() {
        var h = 9
        var mi = 0
        val caja = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        val et = EditText(this).apply { hint = "Tarea o recordatorio" }
        val bh = Button(this).apply { text = "Hora: 09:00" }
        val cb = CheckBox(this).apply {
            text = "Activar alarma"
            isChecked = true
        }
        bh.setOnClickListener {
            TimePickerDialog(this, { _, hh, mm ->
                h = hh
                mi = mm
                bh.text = "Hora: %02d:%02d".format(h, mi)
            }, h, mi, true).show()
        }
        caja.addView(et)
        caja.addView(bh)
        caja.addView(cb)

        AlertDialog.Builder(this)
            .setTitle("Nueva tarea")
            .setView(caja)
            .setPositiveButton("Guardar") { _, _ ->
                val tt = et.text.toString().trim()
                if (tt.isEmpty()) {
                    Toast.makeText(this, "Escribí un título", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val t = Tarea(System.currentTimeMillis(), fecha, h, mi, tt, cb.isChecked, false)
                if (t.alarma && Alarmas.momento(t) <= System.currentTimeMillis()) {
                    Toast.makeText(this, "Esa hora ya pasó: la alarma no sonará", Toast.LENGTH_LONG).show()
                }
                Store.agregar(this, t)
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
