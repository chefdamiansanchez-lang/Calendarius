package com.datco.calendario

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF1B2028.toInt()
        window.navigationBarColor = 0xFF1B2028.toInt()

        val raiz = FrameLayout(this)
        raiz.setBackgroundColor(0xFF1B2028.toInt())

        val centro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            alpha = 0f
            scaleX = 0.85f
            scaleY = 0.85f
        }

        val insignia = TextView(this).apply {
            text = "D"
            textSize = 56f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF007BC7.toInt(), 0xFF00D2FF.toInt())
            ).apply { cornerRadius = dp(28).toFloat() }
        }
        centro.addView(insignia, LinearLayout.LayoutParams(dp(120), dp(120)))

        val titulo = TextView(this).apply {
            text = "DATCO"
            textSize = 34f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            letterSpacing = 0.35f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(8))
        }
        centro.addView(titulo)

        val acro = TextView(this).apply {
            text = "DESARROLLO AVANZADO DE TECNOLOGÍAS\nY CÓDIGOS OPERATIVOS"
            textSize = 10f
            setTextColor(0xFF8FA3B8.toInt())
            letterSpacing = 0.1f
            gravity = Gravity.CENTER
        }
        centro.addView(acro)

        raiz.addView(
            centro,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        val pie = TextView(this).apply {
            text = "Diseño de apps... y algo más"
            textSize = 13f
            setTextColor(0xFF8FA3B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(40))
        }
        raiz.addView(
            pie,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        setContentView(raiz)
        centro.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900).start()

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 2400)
    }
}
