package com.datco.calendario

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private var cal: Calendar = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
    private lateinit var foto: ImageView
    private lateinit var titulo: TextView
    private lateinit var barra: LinearLayout
    private lateinit var semana: LinearLayout
    private lateinit var grid: GridLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pedirPermisos()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        foto = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFFCFD8DC.toInt())
        }
        raiz.addView(foto, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210)))

        barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val ant = flecha("‹") { cal.add(Calendar.MONTH, -1); dibujar() }
        val sig = flecha("›") { cal.add(Calendar.MONTH, 1); dibujar() }
        titulo = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setOnClickListener {
                cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
                dibujar()
            }
        }
        barra.addView(ant)
        barra.addView(titulo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        barra.addView(sig)
        raiz.addView(barra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        semana = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(4))
        }
        for (d in listOf("L", "M", "M", "J", "V", "S", "D")) {
            semana.addView(
                TextView(this).apply {
                    text = d
                    textSize = 14f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(0xFF757575.toInt())
                    gravity = Gravity.CENTER
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        raiz.addView(semana)

        grid = GridLayout(this).apply { columnCount = 7 }
        raiz.addView(grid)

        val hint = TextView(this).apply {
            text = "Tocá un día para ver su agenda · Tocá el mes para volver a hoy"
            textSize = 12f
            setTextColor(0xFF757575.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(20))
        }
        raiz.addView(hint)

        val scroll = ScrollView(this)
        scroll.addView(raiz)
        setContentView(scroll)
        dibujar()
    }

    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized) dibujar()
    }

    private fun flecha(t: String, accion: () -> Unit): TextView = TextView(this).apply {
        text = t
        textSize = 34f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(16), 0, dp(16), dp(4))
        setOnClickListener { accion() }
    }

    private fun pedirPermisos() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun dibujar() {
        val y = cal.get(Calendar.YEAR)
        val m0 = cal.get(Calendar.MONTH)
        val color = Estacion.color(m0 + 1)
        titulo.text = "${MESES[m0]} $y"
        barra.setBackgroundColor(color)
        Imagenes.cargar(this, m0 + 1, foto)

        grid.removeAllViews()
        val ancho = resources.displayMetrics.widthPixels / 7
        val offset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val dias = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val con = Store.fechasConTareas(this)
        val hoy = Calendar.getInstance()

        for (i in 0 until offset) {
            grid.addView(View(this), GridLayout.LayoutParams().apply { width = ancho; height = dp(56) })
        }
        for (d in 1..dias) {
            val f = fechaTexto(y, m0, d)
            val esHoy = hoy.get(Calendar.YEAR) == y && hoy.get(Calendar.MONTH) == m0 &&
                hoy.get(Calendar.DAY_OF_MONTH) == d
            val col = (offset + d - 1) % 7

            val celda = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, DiaActivity::class.java).putExtra("fecha", f))
                }
            }
            val num = TextView(this).apply {
                text = d.toString()
                textSize = 17f
                gravity = Gravity.CENTER
                setTextColor(
                    if (esHoy) Color.WHITE else if (col == 6) 0xFFD32F2F.toInt() else 0xFF212121.toInt()
                )
                if (esHoy) {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(color)
                    }
                }
            }
            celda.addView(num, LinearLayout.LayoutParams(dp(36), dp(36)))
            val punto = TextView(this).apply {
                text = "●"
                textSize = 8f
                setTextColor(0xFFE53935.toInt())
                visibility = if (con.contains(f)) View.VISIBLE else View.INVISIBLE
            }
            celda.addView(punto)
            grid.addView(celda, GridLayout.LayoutParams().apply { width = ancho; height = dp(56) })
        }
    }
}
