package com.datco.calendario

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Vuelve a programar las alarmas cuando se reinicia el teléfono o se actualiza la app
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarmas.reprogramarTodas(c)
        CalWidget.refrescar(c)
    }
}
