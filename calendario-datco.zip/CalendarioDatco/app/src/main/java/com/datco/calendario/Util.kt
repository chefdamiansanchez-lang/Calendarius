package com.datco.calendario

import android.content.Context

val MESES = arrayOf(
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
)
val DIAS = arrayOf("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun fechaTexto(y: Int, m0: Int, d: Int): String = "%04d-%02d-%02d".format(y, m0 + 1, d)

// Estaciones de Argentina (hemisferio sur), con colores sólidos
object Estacion {
    fun nombre(mes: Int): String = when (mes) {
        12, 1, 2 -> "Verano"
        3, 4, 5 -> "Otoño"
        6, 7, 8 -> "Invierno"
        else -> "Primavera"
    }

    fun color(mes: Int): Int = when (mes) {
        12, 1, 2 -> 0xFFF57F17.toInt()
        3, 4, 5 -> 0xFFEF6C00.toInt()
        6, 7, 8 -> 0xFF0288D1.toInt()
        else -> 0xFF43A047.toInt()
    }
}
