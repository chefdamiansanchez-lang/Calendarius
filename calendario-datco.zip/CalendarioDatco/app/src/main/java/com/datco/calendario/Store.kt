package com.datco.calendario

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Tarea(
    val id: Long,
    val fecha: String,
    val hora: Int,
    val minuto: Int,
    val titulo: String,
    val alarma: Boolean,
    val hecha: Boolean
)

// Guarda las tareas en el teléfono (SharedPreferences, formato JSON)
object Store {
    private const val PREF = "calendario_datco"
    private const val KEY = "tareas"

    fun todas(c: Context): MutableList<Tarea> {
        val s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val out = mutableListOf<Tarea>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Tarea(
                        o.getLong("id"), o.getString("fecha"), o.getInt("hora"),
                        o.getInt("minuto"), o.getString("titulo"),
                        o.getBoolean("alarma"), o.getBoolean("hecha")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun guardar(c: Context, lista: List<Tarea>) {
        val arr = JSONArray()
        for (t in lista) {
            arr.put(
                JSONObject()
                    .put("id", t.id).put("fecha", t.fecha).put("hora", t.hora)
                    .put("minuto", t.minuto).put("titulo", t.titulo)
                    .put("alarma", t.alarma).put("hecha", t.hecha)
            )
        }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
        CalWidget.refrescar(c)
    }

    fun deDia(c: Context, fecha: String): List<Tarea> =
        todas(c).filter { it.fecha == fecha }.sortedWith(compareBy({ it.hora }, { it.minuto }))

    fun fechasConTareas(c: Context): Set<String> = todas(c).map { it.fecha }.toSet()

    fun agregar(c: Context, t: Tarea) {
        val l = todas(c)
        l.add(t)
        guardar(c, l)
        Alarmas.programar(c, t)
    }

    fun borrar(c: Context, id: Long) {
        guardar(c, todas(c).filter { it.id != id })
        Alarmas.cancelar(c, id)
    }

    fun marcar(c: Context, id: Long, hecha: Boolean) {
        val l = todas(c).map { if (it.id == id) it.copy(hecha = hecha) else it }
        guardar(c, l)
        val t = l.firstOrNull { it.id == id } ?: return
        if (hecha) Alarmas.cancelar(c, id) else Alarmas.programar(c, t)
    }
}
